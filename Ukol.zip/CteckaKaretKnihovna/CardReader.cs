﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CteckaKaretKnihovna
{
    public class CardReader : ICardReader
    {
        private static readonly Random random = new Random();

        // Náhodné generování UID Karty
        public byte[] GetCardUID()
        {
            byte[] uid = new byte[4];
            random.NextBytes(uid);
            return uid;
        }
    }
}
