using Microsoft.EntityFrameworkCore;
using MyServerApp.Models;

namespace MyServerApp
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Client> Clients { get; set; }
        public DbSet<Card> Cards { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Client>()
                .HasMany(c => c.Cards)
                .WithOne(c => c.Client)
                .HasForeignKey(c => c.ClientId);
        }
    }
}
