using System;
using System.ComponentModel.DataAnnotations;

namespace MyServerApp.Models
{
    public class Card
    {
        public int Id { get; set; }
        public byte[] UID { get; set; }
        public int ClientId { get; set; }
        public Client Client { get; set; }
    }
}

