﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CteckaKaretKnihovna;
using ClientManagement;

namespace CteckaKaret
{
    public partial class Form1 : Form
    {
        private ICardReader cardReader;
        private ClientManager clientManager;

        public Form1()
        {
            InitializeComponent();
            cardReader = new CardReader();
            clientManager = new ClientManager();

        }
        // Zde funkce na kliknutí tlačítka, která vygeneruje UID klientovi pomocí metody GetCardUID z CardReader, pak je vypsán do txtCardUID
        private void btnGetCardUID_Click(object sender, EventArgs e)
        {
            byte[] uid = cardReader.GetCardUID();
            string uidString = BitConverter.ToString(uid).Replace("-", string.Empty).ToUpper();
            // Podmínka, pokud je délka uidStringu větší než 8, tak se zmenší na jen 8 znaků
            if(uidString.Length > 8)        
            {
                uidString = uidString.Substring(0, 8);
            }

            txtCardUID.Text = uidString;
        }
        // Funkce na přídání klienta do databáze
        private void btnAddClient_Click(object sender, EventArgs e)
        {
            //Vytvoření clienta s údajemi, informace z txtboxu se zapíšou do třídy Client
            var client = new Client
            {
                FirstName = txtFirstName.Text,
                LastName = txtLastName.Text,
                Age = (int)numAge.Value,
                Email = txtEmail.Text
            };
            // Podmínka, pokud by chyběl některý vyplněný textbox, tak vyskočí msgbox
            if (string.IsNullOrWhiteSpace(txtFirstName.Text) ||
                string.IsNullOrWhiteSpace(txtLastName.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) ||
                string.IsNullOrWhiteSpace(txtCardUID.Text))
            {
                MessageBox.Show("Prosím, vyplňte všechna povinná pole (jméno, příjmení, email) a vygenerujte UID.", "Chyba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            // Funkce přídává UID k danému klientovi
            if (!string.IsNullOrEmpty(txtCardUID.Text))
            {
                byte[] uid = Enumerable.Range(0, txtCardUID.Text.Length / 2)
                                       .Select(x => Convert.ToByte(txtCardUID.Text.Substring(x * 2, 2), 16))
                                       .ToArray();
                client.CardUIDs.Add(uid);
            }
            clientManager.AddClient(client);
            SaveCardData();  // Uloží data o kartách
            SaveClientData();  // Uloží data o klientech
            ClearClientFields(); // Vyčistí txtboxy 
            MessageBox.Show("Klient byl úspěšně přidán!");
        }

        // Tlačítko na uložení dat o Kartě
        private void btnLoadCardData_Click(object sender, EventArgs e) 
        {
            LoadCardData();
        }
        // Tlačítko na uložení dat o Klientovi
        private void btnLoadClientData_Click(object sender, EventArgs e)
        {
            LoadClientData();
        }
        // Funkce pro načtení dat o Kartě, nebo vypsání, že nejsou žádné data
        private void LoadCardData()
        {
            if (System.IO.File.Exists("KartyData.txt"))
            {
                string data = System.IO.File.ReadAllText("KartyData.txt");
                lblCardData.Text = data;
            }
            else
            {
                lblCardData.Text = "Žádná data nejsou k dispozici.";
            }
        }
        // Funkce pro načtení dat o Klientovi,  nebo vypsání, že nejsou žádné data
        private void LoadClientData()
        {
            if (System.IO.File.Exists("KlientiData.txt"))
            {
                string data = System.IO.File.ReadAllText("KlientiData.txt");
                lblClientData.Text = data;
            }
            else
            {
                lblClientData.Text = "Žádná data nejsou k dispozici.";
            }
        }
        // Funkce pro uložení dat o Kartě, při zobrazení se ukáže Jméno, Příjmení a UID Karty
        private void SaveCardData()
        {
            var clients = clientManager.GetClients();
            var sb = new StringBuilder();

            foreach (var client in clients)
            {
                foreach (var uid in client.CardUIDs)
                {
                    string uidString = BitConverter.ToString(uid).Replace("-", string.Empty).ToUpper();
                    sb.AppendLine($"Jméno: {client.FirstName} {client.LastName} UID: {uidString}");
                }
            }

            System.IO.File.AppendAllText("KartyData.txt", sb.ToString());
        }

        // Funkce pro uložení dat o Klientovi, při zobrazení se ukáže Jméno, Příjmení, Rok a Email
        private void SaveClientData()
        {
            var clients = clientManager.GetClients();
            var sb = new StringBuilder();

            foreach (var client in clients)
            {
                sb.AppendLine($"Jméno: {client.FirstName} {client.LastName} Věk: {client.Age} Email: {client.Email}");
            }

            System.IO.File.AppendAllText("KlientiData.txt", sb.ToString());
        }

        // Funkce, která se zavolá vždy, když se změní text v txtSearchClients
        private void txtSearchClients_TextChanged(object sender, EventArgs e)
        {
            FilterClients(txtSearchClients.Text);
        }
        // Funkce, která se zavolá vždy, když se změní text v txtSearchCards
        private void txtSearchCards_TextChanged(object sender, EventArgs e)
        {
            FilterCards(txtSearchCards.Text);
        }
        private void FilterClients(string searchText)
        {
            var filteredClients = new List<string>();

            if (System.IO.File.Exists("KlientiData.txt"))
            {
                var lines = System.IO.File.ReadAllLines("KlientiData.txt");

                foreach (var line in lines)
                {
                    // Získání částí textu pomocí hledání specifických tagů
                    var namePrefix = "Jméno:";

                    // Najdeme indexy pro jednotlivé tagy
                    var nameStartIndex = line.IndexOf(namePrefix) + namePrefix.Length;

                    // Pokud nejsou nalezeny všechny potřebné části, pokračujeme na další řádek
                    if (nameStartIndex < namePrefix.Length)
                        continue;

                    // Extrakce jednotlivých částí textu
                    var fullName = line.Substring(nameStartIndex).Trim();
                    // Filtrování klientu podle hledaného textu
                    if (fullName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        filteredClients.Add(line);
                    }
                }
            }

            // Zobrazení filtrovaných klientů
            lblClientData.Text = filteredClients.Count > 0 ? string.Join(Environment.NewLine, filteredClients) : "Žádné výsledky.";
        }

        private void FilterCards(string searchText)
        {
            var filteredCards = new List<string>();

            if (System.IO.File.Exists("KartyData.txt"))
            {
                var lines = System.IO.File.ReadAllLines("KartyData.txt");

                foreach (var line in lines)
                {
                    // Získání částí textu pomocí hledání specifických tagů
                    var namePrefix = "Jméno:";
                    var uidPrefix = "UID:";

                    // Nacházení indexů pro jednotlivé tagy
                    var nameStartIndex = line.IndexOf(namePrefix) + namePrefix.Length;
                    var uidStartIndex = line.IndexOf(uidPrefix) + uidPrefix.Length;

                    // Pokud nejsou nalezeny všechny potřebné části, pokračujeme na další řádek
                    if (nameStartIndex < namePrefix.Length || uidStartIndex < uidPrefix.Length)
                        continue;

                    // Extrakce jednotlivých částí textu
                    var fullName = line.Substring(nameStartIndex, line.IndexOf(uidPrefix) - nameStartIndex).Trim();
                    var uid = line.Substring(uidStartIndex).Trim();
                    // Filtrování karet podle hledaného textu
                    if (fullName.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0 || uid.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0)
                    {
                        filteredCards.Add(line);
                    }
                }
            }

            // Zobrazení filtrovaných karet
            lblCardData.Text = filteredCards.Count > 0 ? string.Join(Environment.NewLine, filteredCards) : "Žádné výsledky.";
        }
        // Lokalizace aplikace
        // Tento úkol jsem ještě nikdy nedělal, ale co jsem se tak načetl na internetu, bylo by možné udělat i bez nutnosti rekompilace kódu.
        // 
        // Používali by se externí soubory (.resx, JSON nebo textové soubory), které by obsahovaly překlady textů použitých v aplikaci. Tyto soubory by byly načítány hned po spuštění aplikace
        // Stačilo by tedy implementovat mechanismus, aby uživatel mohl vybrat jazyk a následně by se všechny texty v aplikaci změnily na určený jazyk.
        //
        // např.
        // "en": 
        //      "btnAddClient": "Add Client",
        //      "lblFirstName": "First Name",
        //      "msgClientAdded": "Client has been successfully added!"
        //
        // "cs": {
        //      "btnAddClient": "Přidat klienta",
        //      "lblFirstName": "Jméno",
        //      "msgClientAdded": "Klient byl úspěšně přidán!"
        //
        // Tyto kody pro dané texty by se pak použily ve zdrojovém kodu aplikace. Například místo pevně zadaného textu "Přidat klienta" by aplikace použila kód "btnAddClient" z lokalizačního souboru.
        // Dále už by stačilo jen implementovat čtení souborů s jazykama a přepsat všude části, kde se vypisuje předem daný text za kódy
        //

        // Tlačítko na reset txtboxu
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearClientFields();
        }
        private void ClearClientFields()
        {
            txtFirstName.Clear();
            txtLastName.Clear();
            numAge.Value = 18;
            txtEmail.Clear();
            txtCardUID.Clear();
        }
    }
}
