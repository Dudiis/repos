﻿namespace CteckaKaret
{
    partial class Form1
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtFirstName = new System.Windows.Forms.TextBox();
            this.txtLastName = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.numAge = new System.Windows.Forms.NumericUpDown();
            this.lblname = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnAddClient = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnClear = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btnGetCardUID = new System.Windows.Forms.Button();
            this.txtCardUID = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblCardData = new System.Windows.Forms.Label();
            this.btnLoadCardData = new System.Windows.Forms.Button();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.txtSearchClients = new System.Windows.Forms.TextBox();
            this.lblClientData = new System.Windows.Forms.Label();
            this.btnLoadClientData = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.txtSearchCards = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.numAge)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtFirstName
            // 
            this.txtFirstName.Location = new System.Drawing.Point(69, 19);
            this.txtFirstName.MaxLength = 20;
            this.txtFirstName.Name = "txtFirstName";
            this.txtFirstName.Size = new System.Drawing.Size(144, 20);
            this.txtFirstName.TabIndex = 0;
            // 
            // txtLastName
            // 
            this.txtLastName.Location = new System.Drawing.Point(69, 57);
            this.txtLastName.MaxLength = 20;
            this.txtLastName.Name = "txtLastName";
            this.txtLastName.Size = new System.Drawing.Size(144, 20);
            this.txtLastName.TabIndex = 1;
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(69, 135);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(144, 20);
            this.txtEmail.TabIndex = 3;
            // 
            // numAge
            // 
            this.numAge.Location = new System.Drawing.Point(69, 95);
            this.numAge.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.numAge.Minimum = new decimal(new int[] {
            18,
            0,
            0,
            0});
            this.numAge.Name = "numAge";
            this.numAge.Size = new System.Drawing.Size(41, 20);
            this.numAge.TabIndex = 4;
            this.numAge.Value = new decimal(new int[] {
            18,
            0,
            0,
            0});
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Location = new System.Drawing.Point(22, 22);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(41, 13);
            this.lblname.TabIndex = 5;
            this.lblname.Text = "Jméno:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 60);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Příjmení:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(25, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(29, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Věk:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(19, 138);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "Email:";
            // 
            // btnAddClient
            // 
            this.btnAddClient.Location = new System.Drawing.Point(234, 208);
            this.btnAddClient.Name = "btnAddClient";
            this.btnAddClient.Size = new System.Drawing.Size(108, 36);
            this.btnAddClient.TabIndex = 9;
            this.btnAddClient.Text = "Přidat";
            this.btnAddClient.UseVisualStyleBackColor = true;
            this.btnAddClient.Click += new System.EventHandler(this.btnAddClient_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Location = new System.Drawing.Point(13, 13);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(522, 304);
            this.tabControl1.TabIndex = 10;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnClear);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.btnGetCardUID);
            this.tabPage1.Controls.Add(this.txtCardUID);
            this.tabPage1.Controls.Add(this.btnAddClient);
            this.tabPage1.Controls.Add(this.txtFirstName);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.txtLastName);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.txtEmail);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.numAge);
            this.tabPage1.Controls.Add(this.lblname);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(514, 278);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Přidat klienta";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(357, 208);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(108, 36);
            this.btnClear.TabIndex = 13;
            this.btnClear.Text = "Vymazat";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(7, 174);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 12;
            this.label4.Text = "UID Karty:";
            // 
            // btnGetCardUID
            // 
            this.btnGetCardUID.Location = new System.Drawing.Point(234, 171);
            this.btnGetCardUID.Name = "btnGetCardUID";
            this.btnGetCardUID.Size = new System.Drawing.Size(108, 20);
            this.btnGetCardUID.TabIndex = 11;
            this.btnGetCardUID.Text = "Získej UID";
            this.btnGetCardUID.UseVisualStyleBackColor = true;
            this.btnGetCardUID.Click += new System.EventHandler(this.btnGetCardUID_Click);
            // 
            // txtCardUID
            // 
            this.txtCardUID.BackColor = System.Drawing.SystemColors.Control;
            this.txtCardUID.ForeColor = System.Drawing.Color.DimGray;
            this.txtCardUID.Location = new System.Drawing.Point(69, 171);
            this.txtCardUID.Name = "txtCardUID";
            this.txtCardUID.ReadOnly = true;
            this.txtCardUID.Size = new System.Drawing.Size(144, 20);
            this.txtCardUID.TabIndex = 10;
            this.txtCardUID.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.txtSearchCards);
            this.tabPage2.Controls.Add(this.lblCardData);
            this.tabPage2.Controls.Add(this.btnLoadCardData);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(514, 278);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Karty";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblCardData
            // 
            this.lblCardData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardData.Location = new System.Drawing.Point(3, 3);
            this.lblCardData.Name = "lblCardData";
            this.lblCardData.Size = new System.Drawing.Size(351, 272);
            this.lblCardData.TabIndex = 1;
            // 
            // btnLoadCardData
            // 
            this.btnLoadCardData.Location = new System.Drawing.Point(360, 6);
            this.btnLoadCardData.Name = "btnLoadCardData";
            this.btnLoadCardData.Size = new System.Drawing.Size(148, 63);
            this.btnLoadCardData.TabIndex = 0;
            this.btnLoadCardData.Text = "Načti karty";
            this.btnLoadCardData.UseVisualStyleBackColor = true;
            this.btnLoadCardData.Click += new System.EventHandler(this.btnLoadCardData_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.txtSearchClients);
            this.tabPage3.Controls.Add(this.lblClientData);
            this.tabPage3.Controls.Add(this.btnLoadClientData);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(514, 278);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Klienti";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // txtSearchClients
            // 
            this.txtSearchClients.Location = new System.Drawing.Point(360, 255);
            this.txtSearchClients.Name = "txtSearchClients";
            this.txtSearchClients.Size = new System.Drawing.Size(145, 20);
            this.txtSearchClients.TabIndex = 2;
            this.txtSearchClients.TextChanged += new System.EventHandler(this.txtSearchClients_TextChanged);
            // 
            // lblClientData
            // 
            this.lblClientData.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblClientData.Location = new System.Drawing.Point(3, 3);
            this.lblClientData.Name = "lblClientData";
            this.lblClientData.Size = new System.Drawing.Size(351, 272);
            this.lblClientData.TabIndex = 1;
            // 
            // btnLoadClientData
            // 
            this.btnLoadClientData.Location = new System.Drawing.Point(360, 3);
            this.btnLoadClientData.Name = "btnLoadClientData";
            this.btnLoadClientData.Size = new System.Drawing.Size(146, 63);
            this.btnLoadClientData.TabIndex = 0;
            this.btnLoadClientData.Text = "Načti klienty";
            this.btnLoadClientData.UseVisualStyleBackColor = true;
            this.btnLoadClientData.Click += new System.EventHandler(this.btnLoadClientData_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(361, 236);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 3;
            this.label5.Text = "Vyhledávání";
            // 
            // txtSearchCards
            // 
            this.txtSearchCards.Location = new System.Drawing.Point(360, 258);
            this.txtSearchCards.Name = "txtSearchCards";
            this.txtSearchCards.Size = new System.Drawing.Size(148, 20);
            this.txtSearchCards.TabIndex = 2;
            this.txtSearchCards.TextChanged += new System.EventHandler(this.txtSearchCards_TextChanged);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(361, 239);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 3;
            this.label6.Text = "Vyhledávání";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(541, 323);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.numAge)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtFirstName;
        private System.Windows.Forms.TextBox txtLastName;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.NumericUpDown numAge;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnAddClient;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnGetCardUID;
        private System.Windows.Forms.TextBox txtCardUID;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button btnLoadCardData;
        private System.Windows.Forms.Button btnLoadClientData;
        private System.Windows.Forms.Label lblCardData;
        private System.Windows.Forms.Label lblClientData;
        private System.Windows.Forms.TextBox txtSearchClients;
        private System.Windows.Forms.TextBox txtSearchCards;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

